#!/bin/bash

# تشغيل خادم نظام تقييم BTEC
python simple_app.py