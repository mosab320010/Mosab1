#!/bin/bash

# تشغيل خادم الويب BTEC
echo "بدء تشغيل خادم BTEC..."
python minimal_btec_server.py