#!/bin/bash

# التأكد من تثبيت جميع المتطلبات
pip install -r requirements.txt

# تشغيل الخادم
python app.py