#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
نقطة الدخول الرئيسية لنظام تقييم BTEC
خادم ويب بسيط وفعال
"""

import os
import logging
from flask import Flask, render_template, send_from_directory, jsonify

# إعداد التسجيل
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# إنشاء تطبيق Flask
app = Flask(__name__, 
            static_folder='static', 
            template_folder='templates')

# تكوين سري للتطبيق
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    logger.info("تم طلب الصفحة الرئيسية")
    return render_template('index.html')

@app.route('/static/<path:path>')
def static_file(path):
    """خدمة الملفات الثابتة"""
    return send_from_directory('static', path)

@app.route('/health')
def health():
    """التحقق من صحة النظام"""
    return jsonify({
        'status': 'ok',
        'version': '1.0'
    })

@app.route('/api/status')
def api_status():
    """حالة النظام"""
    return jsonify({
        'status': 'active',
        'system': 'BTEC Evaluation System',
        'version': '1.0.0'
    })

# تشغيل التطبيق
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"تشغيل خادم BTEC على المنفذ {port}")
    app.run(host='0.0.0.0', port=port, debug=True)