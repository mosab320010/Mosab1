# مشروع منصة مُدقِّق - نظرة عامة

## الملفات الرئيسية

### ملفات المنصة الأساسية
mudaqqiq/app/admin/forms.py
mudaqqiq/app/admin/__init__.py
mudaqqiq/app/admin/routes.py
mudaqqiq/app/api/__init__.py
mudaqqiq/app/api/routes.py
mudaqqiq/app/auth/forms.py
mudaqqiq/app/auth/__init__.py
mudaqqiq/app/auth/routes.py
mudaqqiq/app/__init__.py
mudaqqiq/app/main/forms.py
mudaqqiq/app/main/__init__.py
mudaqqiq/app/main/routes.py
mudaqqiq/app/models.py
mudaqqiq/app/projects/forms.py
mudaqqiq/app/projects/__init__.py
mudaqqiq/app/projects/routes.py
mudaqqiq/app/static/css/main.css
mudaqqiq/app/static/img/logo.png
mudaqqiq/app/static/js/main.js
mudaqqiq/app/templates/auth/login.html
mudaqqiq/app/templates/auth/register.html
mudaqqiq/app/templates/auth/reset_password.html
mudaqqiq/app/templates/auth/reset_password_request.html
mudaqqiq/app/templates/base.html
mudaqqiq/app/templates/dashboard.html
mudaqqiq/app/templates/errors/404.html
mudaqqiq/app/templates/errors/500.html
mudaqqiq/app/templates/index.html
mudaqqiq/app/templates/profile.html
mudaqqiq/app/utils.py
mudaqqiq/config.py
mudaqqiq/init_database.py
mudaqqiq/README.md
mudaqqiq/requirements.txt
mudaqqiq/run_mudaqqiq.py
mudaqqiq/run.py
mudaqqiq/USER_GUIDE.md

### ملفات التكامل
- btec_mudaqqiq_integration.py - وحدة التكامل مع نظام BTEC
- run_mudaqqiq_server.py - سكريبت تشغيل خادم التكامل
- run_btec_mudaqqiq.sh - سكريبت تشغيل متكامل
- integrate_mudaqqiq.py - سكريبت دمج المنصة مع النظام

## طرق التشغيل

### 1. تشغيل منصة مُدقِّق بشكل مستقل


### 2. تشغيل منصة مُدقِّق مع نظام BTEC (متكامل)


### 3. دمج منصة مُدقِّق مع نظام BTEC القائم

