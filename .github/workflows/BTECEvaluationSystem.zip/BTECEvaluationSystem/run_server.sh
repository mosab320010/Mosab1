#!/bin/bash

# تشغيل خادم نظام تقييم BTEC
echo "بدء تشغيل خادم نظام تقييم BTEC..."
python run.py