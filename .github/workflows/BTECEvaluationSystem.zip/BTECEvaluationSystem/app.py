#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
نظام تقييم BTEC - تطبيق Flask أساسي
"""

import os
import logging
from datetime import datetime
from flask import Flask, render_template, send_from_directory, jsonify, redirect, url_for

# إعداد التسجيل
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# إنشاء تطبيق Flask
app = Flask(__name__, 
            static_folder='static', 
            template_folder='templates')

# تكوين سري للتطبيق
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    logger.debug("عرض الصفحة الرئيسية")
    return render_template('index.html')

@app.route('/static/<path:path>')
def static_file(path):
    """الملفات الثابتة"""
    return send_from_directory('static', path)

@app.route('/api/health')
def health():
    """التحقق من الصحة"""
    return jsonify({
        'status': 'ok',
        'version': '1.0',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/castle-grok')
def castle_grok():
    """صفحة قلعة Grok الأسطورية"""
    return render_template('castle_grok.html')

@app.route('/mudaqqiq')
def mudaqqiq():
    """صفحة منصة مُدقِّق"""
    return render_template('mudaqqiq.html')

@app.route('/simple')
def simple():
    """صفحة بسيطة للتحقق من عمل النظام"""
    return """
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>نظام تقييم BTEC</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #1a103d;
                color: #f5f3ff;
                text-align: center;
                padding: 50px;
                margin: 0;
            }
            h1 {
                color: #ffdc73;
                font-size: 2.5rem;
            }
            p {
                font-size: 1.2rem;
                margin-bottom: 30px;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                background-color: rgba(74, 50, 167, 0.2);
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>نظام تقييم BTEC</h1>
            <p>مرحبًا بك في النظام! تم تشغيل الخادم بنجاح.</p>
            <p>هذه نسخة مبسطة من النظام تستخدم للتحقق من صحة التشغيل.</p>
            <p><a href="/" style="color: #ffdc73;">العودة إلى الصفحة الرئيسية</a></p>
        </div>
    </body>
    </html>
    """

# التعامل مع الأخطاء
@app.errorhandler(404)
def page_not_found(e):
    """معالجة خطأ 404 - الصفحة غير موجودة"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """معالجة خطأ 500 - خطأ في الخادم"""
    return render_template('500.html'), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"تشغيل نظام تقييم BTEC على المنفذ {port}")
    app.run(host='0.0.0.0', port=port, debug=True)