#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
خادم Flask بسيط للتحقق من صحة نظام تقييم BTEC
"""

import os
from flask import Flask, render_template, send_from_directory, jsonify

# إنشاء تطبيق Flask
app = Flask(__name__, 
            static_folder='static', 
            template_folder='templates')

# تكوين سري للتطبيق
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    return "نظام تقييم BTEC يعمل بشكل صحيح!"

@app.route('/api/health')
def health():
    """التحقق من الصحة"""
    return jsonify({
        'status': 'ok',
        'version': '1.0'
    })

# تشغيل التطبيق إذا تم تنفيذ هذا الملف مباشرة
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)