#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
نقطة الدخول الرئيسية لتطبيق نظام تقييم BTEC
"""

import os
import logging
import sys

# إعداد التسجيل
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# استيراد التطبيق من ملف app.py وليس من المجلد app
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app import app

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    logger.info(f"بدء تشغيل نظام تقييم BTEC على المنفذ {port}")
    app.run(host="0.0.0.0", port=port, debug=True)