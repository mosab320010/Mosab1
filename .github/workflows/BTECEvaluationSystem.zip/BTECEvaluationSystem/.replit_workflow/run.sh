#!/bin/bash
cd "$(dirname "$0")/.."
echo "Starting BTEC Evaluation System..."
python run_btec_server.py
