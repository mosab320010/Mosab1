"""
حزمة بذور لنظام تقييم BTEC
تحتوي على وظائف لإنشاء البيانات الأولية
"""

from .admin_user import create_admin_user

__all__ = ['create_admin_user']