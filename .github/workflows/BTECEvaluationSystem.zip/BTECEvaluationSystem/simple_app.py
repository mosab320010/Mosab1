#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
تطبيق مبسط لنظام تقييم BTEC - يعمل مستقلاً بذاته
"""

import os
import logging
from flask import Flask, render_template, send_from_directory, jsonify

# إعداد التسجيل
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# إنشاء تطبيق Flask
app = Flask(__name__, 
            static_folder='static', 
            template_folder='templates')

# تكوين سري للتطبيق
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    try:
        return render_template('index.html')
    except Exception as e:
        logger.error(f"خطأ في عرض الصفحة الرئيسية: {str(e)}")
        return simple_page("خطأ في عرض الصفحة الرئيسية", str(e))

@app.route('/simple')
def simple():
    """صفحة بسيطة للتحقق من عمل النظام"""
    return simple_page("نظام تقييم BTEC", "مرحبًا بك في النظام! تم تشغيل الخادم بنجاح.")

@app.route('/static/<path:path>')
def static_file(path):
    """الملفات الثابتة"""
    try:
        return send_from_directory('static', path)
    except Exception as e:
        logger.error(f"خطأ في تقديم ملف ثابت {path}: {str(e)}")
        return f"خطأ في تقديم ملف ثابت: {str(e)}", 404

@app.route('/api/health')
def health():
    """التحقق من الصحة"""
    return jsonify({
        'status': 'ok',
        'version': '1.0'
    })

def simple_page(title, message):
    """إنشاء صفحة بسيطة"""
    return f"""
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{title}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #1a103d;
                color: #f5f3ff;
                text-align: center;
                padding: 50px;
                margin: 0;
            }}
            h1 {{
                color: #ffdc73;
                font-size: 2.5rem;
            }}
            p {{
                font-size: 1.2rem;
                margin-bottom: 30px;
            }}
            .container {{
                max-width: 800px;
                margin: 0 auto;
                background-color: rgba(74, 50, 167, 0.2);
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            }}
            a {{
                color: #ffdc73;
                text-decoration: none;
            }}
            a:hover {{
                text-decoration: underline;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>{title}</h1>
            <p>{message}</p>
            <p><a href="/">العودة إلى الصفحة الرئيسية</a></p>
        </div>
    </body>
    </html>
    """

# تشغيل التطبيق
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"تشغيل نظام تقييم BTEC على المنفذ {port}")
    app.run(host='0.0.0.0', port=port, debug=True)