#!/bin/bash
echo "Starting BTEC Evaluation System..."
python run_flask_server.py
