#!/bin/bash
python simple_btec_server.py
