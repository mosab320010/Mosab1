#!/bin/bash

# تشغيل خادم BTEC البسيط
echo "جاري تشغيل خادم BTEC البسيط..."
python3 basic_btec_server.py