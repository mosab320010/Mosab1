#!/bin/bash

# تشغيل خادم نظام تقييم BTEC
echo "بدء تشغيل نظام تقييم BTEC..."
python run_btec.py
