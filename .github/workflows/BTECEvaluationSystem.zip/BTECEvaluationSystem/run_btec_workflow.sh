#!/bin/bash

echo "بدء تشغيل نظام تقييم BTEC..."
echo "مشغل الخادم: python btec_eval_server.py"
python btec_eval_server.py
