#!/bin/bash

# تشغيل خادم BTEC البسيط
echo "جاري تشغيل خادم BTEC البسيط..."
python basic_btec_server.py