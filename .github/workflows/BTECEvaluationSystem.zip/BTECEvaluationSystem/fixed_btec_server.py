#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
خادم مبسط لنظام تقييم BTEC
"""

import os
import logging
from flask import Flask, render_template, send_from_directory, jsonify, request

# إعداد التسجيل
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# إنشاء تطبيق Flask
app = Flask(__name__, 
            static_folder='static', 
            template_folder='templates')

# تكوين سري للتطبيق
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    logger.debug("عرض الصفحة الرئيسية")
    try:
        return render_template('index.html')
    except Exception as e:
        logger.error(f"خطأ في عرض الصفحة الرئيسية: {str(e)}")
        return f"خطأ في عرض الصفحة الرئيسية: {str(e)}", 500

@app.route('/static/<path:path>')
def static_file(path):
    """الملفات الثابتة"""
    logger.debug(f"طلب ملف ثابت: {path}")
    try:
        return send_from_directory('static', path)
    except Exception as e:
        logger.error(f"خطأ في تقديم ملف ثابت {path}: {str(e)}")
        return f"خطأ في تقديم ملف ثابت: {str(e)}", 404

@app.route('/api/health')
def health():
    """التحقق من الصحة"""
    return jsonify({
        'status': 'ok',
        'version': '1.0'
    })

@app.route('/castle-grok')
def castle_grok():
    """صفحة قلعة Grok الأسطورية"""
    try:
        return render_template('castle_grok.html')
    except Exception as e:
        logger.error(f"خطأ في عرض صفحة قلعة Grok: {str(e)}")
        return f"خطأ في عرض صفحة قلعة Grok: {str(e)}", 500

@app.route('/mudaqqiq')
def mudaqqiq():
    """صفحة منصة مُدقِّق"""
    try:
        return render_template('mudaqqiq.html')
    except Exception as e:
        logger.error(f"خطأ في عرض صفحة مُدقِّق: {str(e)}")
        return f"خطأ في عرض صفحة مُدقِّق: {str(e)}", 500

# التعامل مع الأخطاء
@app.errorhandler(404)
def page_not_found(e):
    """معالجة خطأ 404 - الصفحة غير موجودة"""
    logger.warning(f"صفحة غير موجودة: {request.path}")
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """معالجة خطأ 500 - خطأ في الخادم"""
    logger.error(f"خطأ داخلي في الخادم: {str(e)}")
    return render_template('500.html'), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"بدء تشغيل خادم BTEC على المنفذ {port}")
    app.run(host='0.0.0.0', port=port, debug=True)