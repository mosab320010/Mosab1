"""
حزمة النماذج لنظام تقييم BTEC
توفر هذه الحزمة نماذج قاعدة البيانات المستخدمة في النظام
"""

from .user import User
from .task import Task